@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\stop-lan-dev.ps1" -StopDatabase
pause

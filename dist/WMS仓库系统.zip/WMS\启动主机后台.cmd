@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\start-packaged-lan-host.ps1" -InteractiveSetup
pause

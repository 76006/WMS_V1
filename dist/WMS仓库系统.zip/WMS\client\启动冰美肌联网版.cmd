@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0start-client.ps1" -Product IceBeauty
if errorlevel 1 pause

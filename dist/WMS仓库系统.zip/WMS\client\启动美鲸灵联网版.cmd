@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0start-client.ps1" -Product MeiJingLing
if errorlevel 1 pause

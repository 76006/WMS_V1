﻿param([ValidateSet('IceBeauty','MeiJingLing')][string]$Product='IceBeauty')
$ErrorActionPreference='Stop'
$addressFile = Join-Path $PSScriptRoot 'server-address.txt'
$savedAddress = if ([IO.File]::Exists($addressFile)) { [IO.File]::ReadAllText($addressFile).Trim() } else { '' }
$server = $savedAddress
$address = $null
while (![Net.IPAddress]::TryParse($server,[ref]$address) -or
       $address.AddressFamily -ne [Net.Sockets.AddressFamily]::InterNetwork -or
       $address.ToString() -ne $server -or [Net.IPAddress]::IsLoopback($address) -or $server -eq '0.0.0.0') {
    $server = Read-Host '请输入主机启动窗口显示的局域网 IPv4 地址，直接回车退出'
    if ([string]::IsNullOrWhiteSpace($server)) { return }
    $server = $server.Trim()
}
if ($server -ne $savedAddress) {
    try { [IO.File]::WriteAllText($addressFile,$server,[Text.Encoding]::ASCII) }
    catch { Write-Warning '本次将使用输入的地址。此目录无法保存设置，下次请重新输入。' }
}
$port=if($Product -eq 'IceBeauty'){18080}else{18081}
Remove-Item Env:WMS_DEMO_LOGIN_PASSWORD -ErrorAction SilentlyContinue
Start-Process -FilePath (Join-Path $PSScriptRoot "$($Product)WmsLan.exe") -ArgumentList @('--server',"http://${server}:$port") -WorkingDirectory $PSScriptRoot

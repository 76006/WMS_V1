@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\import-legacy-data.ps1"
pause
